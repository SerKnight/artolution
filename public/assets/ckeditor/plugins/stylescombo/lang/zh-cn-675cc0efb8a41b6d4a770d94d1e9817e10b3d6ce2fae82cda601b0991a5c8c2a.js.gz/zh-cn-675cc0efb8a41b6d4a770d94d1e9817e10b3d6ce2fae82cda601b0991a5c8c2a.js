/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'stylescombo', 'zh-cn', {
	label: '样式',
	panelTitle: '样式',
	panelTitle1: '块级元素样式',
	panelTitle2: '内联元素样式',
	panelTitle3: '对象元素样式'
});
