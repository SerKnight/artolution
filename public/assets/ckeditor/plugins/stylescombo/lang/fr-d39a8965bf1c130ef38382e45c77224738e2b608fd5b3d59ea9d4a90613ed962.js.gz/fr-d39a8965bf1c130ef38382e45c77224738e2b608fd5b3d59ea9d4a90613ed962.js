/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'stylescombo', 'fr', {
	label: 'Styles',
	panelTitle: 'Styles de mise en page',
	panelTitle1: 'Styles de blocs',
	panelTitle2: 'Styles en ligne',
	panelTitle3: 'Styles d\'objet'
});
