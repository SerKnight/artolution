/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'stylescombo', 'hr', {
	label: 'Stil',
	panelTitle: 'Stilovi formatiranja',
	panelTitle1: 'Block stilovi',
	panelTitle2: 'Inline stilovi',
	panelTitle3: 'Object stilovi'
});
